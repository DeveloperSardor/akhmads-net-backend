// src/services/admin/broadcastService.js
import prisma from '../../config/database.js';
import logger from '../../utils/logger.js';
import encryption from '../../utils/encryption.js';
import telegramAPI from '../../utils/telegram-api.js';
import walletService from '../wallet/walletService.js';

class BroadcastService {
  /**
   * Create a new broadcast campaign
   */
  async createBroadcast(advertiserId, data) {
    const {
      botId,
      contentType, // TEXT, HTML, etc.
      text,
      mediaUrl,
      mediaType,
      buttons,
      targetCount, // How many users to send to
      activeDays = 30 // Threshold for active users
    } = data;

    try {
      // 1. Validate bot
      const bot = await prisma.bot.findUnique({ where: { id: botId } });
      if (!bot || bot.status !== 'ACTIVE') {
        throw new Error('Bot is not active or not found');
      }

      // 2. Find target users
      const threshold = new Date();
      threshold.setDate(threshold.getDate() - parseInt(activeDays));
      
      const availableUsers = await prisma.botUser.findMany({
        where: {
          botId,
          lastSeenAt: { gte: threshold },
        },
        select: { id: true, telegramUserId: true },
      });

      if (availableUsers.length === 0) {
        throw new Error('No active users found for this bot in specified period');
      }

      // Shuffle and pick targetCount
      const usersToNotify = availableUsers
        .sort(() => 0.5 - Math.random())
        .slice(0, Math.min(targetCount, availableUsers.length));

      const actualTargetCount = usersToNotify.length;

      // 3. Calculate cost
      // Base fee + $0.05 per targeted user
      const baseFee = 0.50; // Minimal protocol fee
      const pricePerMessage = 0.05; 
      const totalCost = (actualTargetCount * pricePerMessage) + baseFee;
      const platformFee = totalCost * 0.30;
      const botOwnerEarn = (actualTargetCount * pricePerMessage) * 0.70;

      // 4. Charge advertiser
      await walletService.debit(advertiserId, totalCost, 'AD_SPEND', 'Broadcast');

      // 5. Create Broadcast record (PENDING — awaiting admin moderation)
      const broadcast = await prisma.broadcast.create({
        data: {
          advertiserId,
          botId,
          status: 'PENDING_REVIEW',
          contentType,
          text,
          mediaUrl,
          mediaType,
          buttons,
          targetCount: actualTargetCount,
          totalCost,
          platformFee,
          botOwnerEarn,
        }
      });

      // 6. Create recipients (will be sent after admin approval)
      const recipientData = usersToNotify.map(u => ({
        broadcastId: broadcast.id,
        botUserId: u.id,
        status: 'PENDING'
      }));

      await prisma.broadcastRecipient.createMany({
        data: recipientData
      });

      return broadcast;
    } catch (error) {
      logger.error('Create broadcast failed:', error);
      throw error;
    }
  }

  /**
   * Background process to send broadcast messages
   */
  async processBroadcast(broadcastId) {
    try {
      const broadcast = await prisma.broadcast.findUnique({
        where: { id: broadcastId },
        include: { bot: true }
      });

      if (!broadcast || broadcast.status !== 'APPROVED') return;

      // Update status to RUNNING
      await prisma.broadcast.update({
        where: { id: broadcastId },
        data: { status: 'RUNNING', startedAt: new Date() }
      });

      const bot = broadcast.bot;
      const botToken = encryption.decrypt(bot.tokenEncrypted);

      const recipients = await prisma.broadcastRecipient.findMany({
        where: { broadcastId, status: 'PENDING' },
        include: { botUser: true }
      });

      logger.info(`Starting broadcast ${broadcastId} to ${recipients.length} users`);

      for (const recipient of recipients) {
        try {
          // Send message
          await this.sendTGMessage(botToken, recipient.botUser.telegramUserId, broadcast);

          // Update recipient
          await prisma.broadcastRecipient.update({
            where: { id: recipient.id },
            data: { status: 'SENT', sentAt: new Date() }
          });

          // Update broadcast counts
          await prisma.broadcast.update({
            where: { id: broadcastId },
            data: { sentCount: { increment: 1 } }
          });

          // Sleep slightly to avoid TG rate limits if needed
          await new Promise(r => setTimeout(r, 50)); // 20 messages per second per bot (standard TG limit is ~30)
          
        } catch (err) {
          logger.error(`Failed to send broadcast to ${recipient.botUser.telegramUserId}:`, err.message);
          
          await prisma.broadcastRecipient.update({
            where: { id: recipient.id },
            data: { status: 'FAILED', error: err.message }
          });

          await prisma.broadcast.update({
            where: { id: broadcastId },
            data: { failedCount: { increment: 1 } }
          });
        }
      }

      // Mark as completed
      await prisma.broadcast.update({
        where: { id: broadcastId },
        data: { status: 'COMPLETED', completedAt: new Date() }
      });

      // Credit bot owner
      await walletService.credit(bot.ownerId, broadcast.botOwnerEarn, 'EARNINGS', broadcast.id);

      logger.info(`Broadcast ${broadcastId} completed`);
    } catch (error) {
      logger.error(`Broadcast process fatal error: ${broadcastId}`, error);
      await prisma.broadcast.update({
        where: { id: broadcastId },
        data: { status: 'PAUSED' } // Or failed
      });
    }
  }

  async sendTGMessage(botToken, chatId, broadcast) {
    const { contentType, text, mediaUrl, mediaType, buttons } = broadcast;

    // Prepare buttons with color support (same as distributionService)
    let replyMarkup = null;
    if (buttons && Array.isArray(buttons) && buttons.length > 0) {
      replyMarkup = {
        inline_keyboard: [
          buttons.map(btn => {
            let style = btn.style;
            if (btn.color === 'green') style = 'success';
            else if (btn.color === 'red') style = 'danger';
            else if (btn.color === 'blue') style = 'primary';
            return { text: btn.text, url: btn.url, style };
          })
        ]
      };
    }

    if (contentType === 'MEDIA' && mediaUrl) {
      if (mediaType?.startsWith('image')) {
        return await telegramAPI.sendPhoto(botToken, {
          chat_id: chatId,
          photo: mediaUrl,
          caption: text,
          parse_mode: 'HTML',
          reply_markup: replyMarkup
        });
      } else if (mediaType?.startsWith('video')) {
        return await telegramAPI.sendVideo(botToken, {
          chat_id: chatId,
          video: mediaUrl,
          caption: text,
          parse_mode: 'HTML',
          reply_markup: replyMarkup
        });
      }
    }

    return await telegramAPI.sendMessage(botToken, {
      chat_id: chatId,
      text: text,
      parse_mode: 'HTML',
      reply_markup: replyMarkup ? JSON.stringify(replyMarkup) : undefined
    });
  }

  async approveBroadcast(broadcastId, adminId) {
    const broadcast = await prisma.broadcast.findUnique({ where: { id: broadcastId } });
    if (!broadcast) throw new Error('Broadcast not found');
    if (broadcast.status !== 'PENDING_REVIEW') throw new Error('Broadcast is not pending');

    await prisma.broadcast.update({
      where: { id: broadcastId },
      data: { status: 'APPROVED' }
    });

    // Run in background
    this.processBroadcast(broadcastId).catch(err => {
      logger.error(`Broadcast process failed after approval: ${broadcastId}`, err);
    });

    // Notify advertiser
    try {
      const advertiser = await prisma.user.findUnique({ where: { id: broadcast.advertiserId }, select: { telegramId: true, locale: true } });
      if (advertiser?.telegramId) {
        const { default: telegramBot } = await import('../../config/telegram.js');
        await telegramBot.bot.api.sendMessage(
          advertiser.telegramId,
          `✅ <b>Broadcast tasdiqlandi!</b>\n\n🆔 ID: <code>${broadcastId}</code>\n👥 Qabul qiluvchilar: ${broadcast.targetCount} ta\n\nYaqin orada yuboriladi.`,
          { parse_mode: 'HTML' }
        ).catch(() => {});
      }
    } catch (e) {
      logger.warn('Failed to notify advertiser on broadcast approve:', e.message);
    }

    return await prisma.broadcast.findUnique({ where: { id: broadcastId } });
  }

  async rejectBroadcast(broadcastId, adminId, reason) {
    const broadcast = await prisma.broadcast.findUnique({ where: { id: broadcastId } });
    if (!broadcast) throw new Error('Broadcast not found');
    if (broadcast.status !== 'PENDING_REVIEW') throw new Error('Broadcast is not pending');

    await prisma.broadcast.update({
      where: { id: broadcastId },
      data: { status: 'REJECTED' }
    });

    // Refund advertiser
    try {
      await walletService.credit(broadcast.advertiserId, broadcast.totalCost, 'REFUND', broadcastId);
    } catch (e) {
      logger.error('Broadcast reject refund failed:', e);
    }

    // Notify advertiser
    try {
      const advertiser = await prisma.user.findUnique({ where: { id: broadcast.advertiserId }, select: { telegramId: true } });
      if (advertiser?.telegramId) {
        const { default: telegramBot } = await import('../../config/telegram.js');
        await telegramBot.bot.api.sendMessage(
          advertiser.telegramId,
          `❌ <b>Broadcast rad etildi</b>\n\n🆔 ID: <code>${broadcastId}</code>\n📝 Sabab: ${reason || 'Moderatsiya qoidalariga mos kelmaydi'}\n\n💰 $${broadcast.totalCost.toFixed(2)} hamyoningizga qaytarildi.`,
          { parse_mode: 'HTML' }
        ).catch(() => {});
      }
    } catch (e) {
      logger.warn('Failed to notify advertiser on broadcast reject:', e.message);
    }

    return await prisma.broadcast.findUnique({ where: { id: broadcastId } });
  }

  async requestBroadcastEdit(broadcastId, adminId, feedback) {
    const broadcast = await prisma.broadcast.findUnique({ where: { id: broadcastId } });
    if (!broadcast) throw new Error('Broadcast not found');

    await prisma.broadcast.update({
      where: { id: broadcastId },
      data: { status: 'DRAFT' }
    });

    // Notify advertiser
    try {
      const advertiser = await prisma.user.findUnique({ where: { id: broadcast.advertiserId }, select: { telegramId: true } });
      if (advertiser?.telegramId) {
        const { default: telegramBot } = await import('../../config/telegram.js');
        await telegramBot.bot.api.sendMessage(
          advertiser.telegramId,
          `✏️ <b>Broadcast tahrir so'raldi</b>\n\n🆔 ID: <code>${broadcastId}</code>\n📝 Izoh: ${feedback}\n\nSaytga kiring va broadcastni qayta yuboring.`,
          { parse_mode: 'HTML' }
        ).catch(() => {});
      }
    } catch (e) {
      logger.warn('Failed to notify advertiser on broadcast edit request:', e.message);
    }

    return await prisma.broadcast.findUnique({ where: { id: broadcastId } });
  }

  async getBroadcasts(advertiserId = null, filters = {}) {
    const { limit = 20, offset = 0, status } = filters;
    const where = {};
    if (advertiserId) where.advertiserId = advertiserId;
    if (status) where.status = status;

    const broadcasts = await prisma.broadcast.findMany({
      where,
      include: {
        bot: { select: { username: true, id: true } },
        advertiser: { select: { id: true, firstName: true, lastName: true, username: true, telegramId: true } }
      },
      orderBy: { createdAt: 'desc' },
      take: parseInt(limit),
      skip: parseInt(offset)
    });

    const total = await prisma.broadcast.count({ where });

    return { broadcasts, total };
  }
}

export default new BroadcastService();
